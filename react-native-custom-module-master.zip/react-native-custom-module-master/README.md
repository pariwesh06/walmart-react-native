
## Usage
 getModuleList() fetches list of native modules. This is only boilerplate implementation to build native module in React Natve.
```
import CustomModule from 'react-native-custom-module';

CustomModule.getModuleList((error, list) => { 
  if (error) { 
      //error 
  } else { 
      console.log(list)
      //array list returned [...] 
  }
});

1. `npm install react-native-custom-module@https://github.com/httpdeveloper/react-native-custom-module.git --save`
2. `react-native link react-native-custom-module`
