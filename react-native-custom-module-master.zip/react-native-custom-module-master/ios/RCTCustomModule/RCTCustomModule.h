//
//  RCTCustomModule.h
//  RCTCustomModule
//

#import <React/RCTBridgeModule.h>

@interface RCTCustomModule : NSObject <RCTBridgeModule>
@end