import React from 'react';
import { StyleSheet, Text, View, Button, TextInput, FlatList } from 'react-native';

export class DetailsScreen extends React.Component {
    render() {
        const { params } = this.props.navigation.state;
        return (
            <View >
                <Text>Details Screen</Text>  
                <Text>{params.itemId}</Text>
                <Button
                    title="Go to Home"
            onPress={() => this.props.navigation.goBack()} /></View>)
    }
}