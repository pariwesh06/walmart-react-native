import React from 'react';
import { StyleSheet, Text, View, SectionList, FlatList, Image, Button } from 'react-native';
export default class LogoTitle extends React.Component {
  render() {
    return (
      <Text

        
      >aeda</Text>
    );
  }
}