import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import {  Image, Button, Alert, TextInput, FlatList, SectionList } from 'react-native';
import Userform from './components/Userform';
import BookList from './components/BookList';
import AppStateExample from './components/AppStateExample';
import HomeScreen from './components/Home';
import DetailsScreen from './components/Details';


// import RootStack from './components/Root'
import {
  StackNavigator,
} from 'react-navigation';

// const App = StackNavigator({
//   Home: { screen: HomeScreen }
//   // Profile: { screen: ProfileScreen },
// });
const RootStack = StackNavigator({
  Home: {
    screen: HomeScreen
  },
  DetailsScreen: {
    screen: DetailsScreen
  },
  BookListScreen:{
    screen:BookList
  }
},
  {
    initialRouteName: 'BookListScreen',
     navigationOptions: {
    headerStyle: {
      backgroundColor: '#f4511e',
    },
    headerTintColor: '#fff',
    headerTitleStyle: {
      fontWeight: 'bold',
    },
     }
  });
export default class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      text: 'ram',
      list: [{ key: 'Devin' }]
    }
  }
  render() {

    return (
      <RootStack ></RootStack>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0EE',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
