import React from 'react';
import { StyleSheet, Text, View, SectionList, FlatList, Image, Button } from 'react-native';

export default class BookList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: true,
      books: []
    }
  }
  componentDidMount() {

  }
  getBooks() {
    fetch('http://it-ebooks-api.info/v1/search/jquery').then(function (response) {
      response.json().then(function (result) {
        // this.state.books=result.Books;  //this won't work
        if (!result.Books) {
          alert('zero results');
          return;
        }
        // result.Books.map((book)=>book.key=book.ID);
        // console.log(result.Books.length);

        this.setState({
          books: result.Books
        });
      }.bind(this));
    }.bind(this));;
  }
  render() {
    return (<View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>Book List</Text>
      <Button
        onPress={this.getBooks.bind(this)}
        title="Info"
        color="#00f"
      />
      <FlatList
        data={this.state.books} keyExtractor={(book, index) => book.ID}
        renderItem={({ item }) => {
          return (<View style={{ flex: 2, alignItems: 'flex-start', justifyContent: 'center' }}>
           <Image style={styles.image} source={{ uri: item.Image}}/>
           <Text  >{item.Title}</Text>
          </View>)
        }}
      />
    </View>
    )
  }
}


const styles = StyleSheet.create({
  image: {
    width: 60,
    height: 51,
    resizeMode: Image.resizeMode.contain,
  },
  container: {
    flex: 1,
    backgroundColor: '#0EF',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
