import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { AppRegistry, Image, Button, Alert, TextInput, FlatList, TabBarBottom, SectionList } from 'react-native';
// import Userform from './components/Userform';
// import BookList from './components/BookList';
// import AppStateExample from './components/AppStateExample';
// import HomeScreen from './components/Home';
// import DetailsScreen from './components/Details';
import { Ionicons } from '@expo/vector-icons';
import { TabNavigator } from 'react-navigation';

class HomeScreen extends React.Component {
  render() {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <Text>Home!</Text>
      </View>
    );
  }
}

class SettingsScreen extends React.Component {
  render() {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <Text>Settings!</Text>
      </View>
    );
  }
}

const RootStack = TabNavigator({
  Home: { screen: HomeScreen },
  Settings: { screen: SettingsScreen }
},
  {
    navigationOptions: ({ navigation }) => ({
      tabBarIcon: ({ focused, tintColor }) => {
        const { routeName } = navigation.state;
        let iconName;
        if (routeName === 'Home') {
          iconName = `ios-information-circle${focused ? '' : '-outline'}`;
        } else if (routeName === 'Settings') {
          iconName = `ios-options${focused ? '' : '-outline'}`;

          // You can return any component that you like here! We usually use an
          // icon component from react-native-vector-icons
          return <Ionicons name={iconName} size={25} color={tintColor} />;
        }},
      }),
  //   tabBarOptions: {
  //     activeTintColor: 'tomato',
  //     inactiveTintColor: 'gray',
  //   },
  //   tabBarComponent: TabBarBottom,
  //   tabBarPosition: 'bottom',
  //   animationEnabled: false,
    swipeEnabled: false
  }
);

export default class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      text: 'ram',
      list: [{ key: 'Devin' }]
    }
  }
  render() {

    return (
      <RootStack ></RootStack>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0EE',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
