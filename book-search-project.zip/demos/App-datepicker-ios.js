
import React from 'react';
import { View, Text, Button, TouchableWithoutFeedback, DatePickerIOS ,StyleSheet} from 'react-native';
import { StackNavigator } from 'react-navigation';
import DetailsScreen from './Details';
import LogoTitle from './LogoTitle';
export default class HomeScreen extends React.Component {
  static navigationOptions = ({ navigation }) => {
    const params = navigation.state.params || {};

    return {
      headerTitle: <LogoTitle />,

    }
  }

  componentWillMount() {
    this.props.navigation.setParams({ increaseCount: this._increaseCount });
  }
  render() {
    return (
      <View style={styles.container}>
        <Text>Home Screen</Text>
        <DatePickerIOS
          date={new Date()}
          onDateChange={this.setDate}
        />
        <Text>selected date:{JSON.stringify(this.state.chosenDate)}</Text>
       
      
      </View>
    );
  }
  setDate(newDate) {
    this.setState({ chosenDate: newDate });
  }
  constructor(props) {
    super(props);
    this.state = { chosenDate: new Date() };

    this.setDate = this.setDate.bind(this);
  }
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center'
  },
})