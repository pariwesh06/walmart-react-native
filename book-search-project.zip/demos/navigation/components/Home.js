
import React from 'react';
import { View, Text, Button } from 'react-native';
import { StackNavigator } from 'react-navigation';
import DetailsScreen from './Details';
import LogoTitle from './LogoTitle';
export default class HomeScreen extends React.Component {
  static navigationOptions = ({ navigation}) => {
    const params = navigation.state.params || {};

    return {
      headerTitle: <LogoTitle />,
      headerRight: (
        <Button
          onPress={params.increaseCount}
          title="Info"
          color="#00f"
        />
      ),
      // headerStyle: {
      //   backgroundColor: '#f4511e',
      // },
      // headerTintColor: '#fff',
      // headerTitleStyle: {
      //   fontWeight: 'bold',
      // },
    }
  }

  componentWillMount() {
    this.props.navigation.setParams({ increaseCount: this._increaseCount });
  }

  state = {
    count: 0,
  };

  _increaseCount = () => {
    this.setState({ count: this.state.count + 1 });
  };

  render() {
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
        <Text>Home Screen</Text>
        <Button
          title="Go to BookList"
          onPress={() => {
            console.log(this.props.navigation.navigate); this.props.navigation.navigate('DetailsScreen',
              {
                itemId: 86,
                otherParam: 'anything you want here',
              })
          }} />
      </View>
    );
  }
}
