import React from 'react';
import { StyleSheet, Text, View, SectionList , FlatList, Image, Button} from 'react-native';

export default class BookList extends React.Component {
  constructor(props) {
    super(props);
    this.state = { isLoading: true ,
      books:[{Title:'book1'}]}
  }
  // componentDidMount() {
  //   fetch('http://it-ebooks-api.info/v1/search/jquery').then(function (response) {
  //     response.json().then(function (result) {
  //       // console.log(result.Books);
  //       // this.state.books=result.Books;  //this won't work
  //       if (!result.Books) {
  //         alert('zero results');
  //         return;
  //       }
  //       this.setState({
  //         books: result.Books
  //       })
  //     }.bind(this));
  //   }.bind(this));
  // }
  render() {
    return (  <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>Book List</Text>
      <FlatList
          data={this.state.books}
          renderItem={({ item }) => <Text style={styles.item}>{item.Title}</Text>}
        />
     </View>
    )
  }
}


const styles = StyleSheet.create({
  image:{
    width: 60,
    height: 51,
    resizeMode: Image.resizeMode.contain,
  },
  container: {
    flex: 1,
    backgroundColor: '#0EF',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
