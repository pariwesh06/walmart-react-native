import React from 'react';
// import {  Text,  TouchableHighlight,  View,} from 'react-native';
import Enzyme,{ shallow } from 'enzyme';
import Adapter from 'enzyme-adapter-react-15.4';
import AddItem from '../AddItem';
// import RepoItem, { styles } from '../RepoItem';
// import { repos } from '../../../config/jest/mockData';
Enzyme.configure({ adapter: new Adapter() });
test('test search',()=>{
  const wrapper = shallow(
      <AddItem />
    );
  console.log('test##############');;
})

test('object assignment', () => {
  const data = {one: 1};
  data['two'] = 2;
  expect(data).toEqual({one: 1, two: 2});
});