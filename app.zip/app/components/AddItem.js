import React, { Component } from 'react';
import {
  StyleSheet,  Text, TextInput,  TouchableHighlight,  View, Button
} from 'react-native';
import { repositories } from '../utils/endpoints';
import { connect } from 'react-redux'
import { fetchData, receiveRepos } from '../actions/api';

class AddItem extends Component {
  constructor(props) {
        super(props);
        // alert(props.actions);
    this.state = {
      query: 'java'
    }
  }
  search=()=> {
    this.props.getRepos(this.state.query);
  }
  render() {
    return (<View>
      <TextInput onChangeText={(value)=>this.setState({query:value})}
        value={this.state.query} />
      <Button
        onPress={this.search}
        title="Save"
        color="#841584" 
      />
    </View>)
  }
}

export default connect(
  (state) => ({ repos: state.repos }),
  (dispatch) => ({
    getRepos: (query) => dispatch(fetchData(repositories+query, receiveRepos)),
    selectRepo: (id) => dispatch(selectRepo(id))
  })
)(AddItem);