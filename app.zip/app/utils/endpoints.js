const baseUrl = 'https://api.github.com/';

export const repositories = `${baseUrl}search/repositories?sort=stars&order=desc&q=`;