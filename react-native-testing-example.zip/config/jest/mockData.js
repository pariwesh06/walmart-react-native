export const repos = [
  {
    description: 'Useful description goes here.',
    id: 1,
    name: 'Test 1',
    stargazers_count: 50000,
  },
  {
    description: 'Useful description goes here.',
    name: 'Test 2',
    id: 2,
    stargazers_count: 10000,
  },
  {
    description: 'Useful description goes here.',
    name: 'Test 3',
    id: 3,
    stargazers_count: 499,
  },
];