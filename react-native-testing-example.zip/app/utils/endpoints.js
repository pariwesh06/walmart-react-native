const baseUrl = 'https://api.github.com/';

export const repositories = `${baseUrl}search/repositories?q=react-native&sort=stars&order=desc`;