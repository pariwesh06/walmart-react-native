

Install dependencies:

```
$ npm install
```

Run tests:

```
$ npm test
```

You can also run them in watch mode:
```
$ npm test -- --watch
```

In this mode, you can play changing the app behaviour, breaking the tests and fixing them!
