import { AppRegistry } from 'react-native';

import Root from './app/setup';

AppRegistry.registerComponent('ReactNativeTestingExample', () => Root);
