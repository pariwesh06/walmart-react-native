import React from 'react';
import { StyleSheet, Text, View, Button, TextInput, FlatList } from 'react-native';

export  class HomeScreen extends React.Component
{
    render(){
        return (<Text>Home Screen</Text>)
    }
}