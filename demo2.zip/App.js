import React from 'react';
import { StyleSheet, Text, View, Button, TextInput,FlatList } from 'react-native';
import { StackNavigator } from 'react-navigation';
import {HomeScreen} from './components/HomeScreen';
RootStack = StackNavigator({
  Home: {
    screen: HomeScreen,
  }
},{
  initialRouteName: 'Home' 
});
export default class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = { text: 'Useless' , users:['Ram']};
    this.clicked = this.clicked.bind(this);
  }
  clicked() {
    this.setState({
      users:[...this.state.users,this.state.text]
    });
    // alert(this.state.users.length)
  }
  render() {
    return (
      <RootStack/>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'flex-start',
    justifyContent: 'center',
  },
  button: { height: 40, width: 60, borderColor: 'red', borderWidth: 1 }
});
